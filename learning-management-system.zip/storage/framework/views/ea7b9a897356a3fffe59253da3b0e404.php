<span class="current-title"><?php echo e($title); ?></span>

<div class="row" id="section-list-<?php echo e($uri_key); ?>">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-body p-3">
                <div class="row">
                    <div class="col-8 col-md-6">
                        <?php $__currentLoopData = $more_actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($ma['key']) && in_array($ma['key'], $permissions)): ?>
                        <?php echo $ma['html_button']; ?>

                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="col-4 col-md-6">
                        <small class="count-total-list-<?php echo e($uri_key); ?> float-end mt-2">0 Data</small>
                    </div>
                    <div class="col-md-12">
                        <form id="form-filter-list-<?php echo e($uri_key); ?>" action="<?php echo e($uri_list_api); ?>" method="get">
                            <div class="row my-3">
                                <div class="col-md-2">
                                    <small for="">Search</small>
                                    <div class="form-group">
                                        <input class="form-control search-list-<?php echo e($uri_key); ?>" name="search" placeholder="Type for search...">
                                        <input type="hidden" name="route_name" class="route-name-<?php echo e($uri_key); ?>" value="<?php echo e($uri_key); ?>">
                                        <input type="hidden" name="page" class="current-paginate-<?php echo e($uri_key); ?>">
                                        <input type="hidden" name="order" class="current-order-<?php echo e($uri_key); ?>">
                                        <input type="hidden" name="order_state" class="current-order-state-<?php echo e($uri_key); ?>" value="ASC">
                                    </div>
                                </div>
                                <?php if(isset($filters)): ?>
                                <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('easyadmin::backend.idev.filters.'.$filter['type'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="table-responsive p-0">
                    <table id="table-list-<?php echo e($uri_key); ?>" class="table table-striped">
                        <thead>
                            <tr>
                                <?php $__currentLoopData = $table_headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $header_name = $header['name'];
                                $header_column = $header['column'];
                                ?>
                                <?php if($header['order']): ?>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"><?php echo e($header_name); ?>

                                    <button class="btn btn-sm btn-link" onclick="orderBy('list-<?php echo e($uri_key); ?>','<?php echo e($header_column); ?>')"><i class="bi bi-arrow-up"></i></button>
                                </th>
                                <?php else: ?>
                                <th style="white-space: nowrap;"><?php echo e($header_name); ?>

                                </th>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <th class="col-action"></th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                    <div id="paginate-list-<?php echo e($uri_key); ?>" class="mt-4"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="section-preview-<?php echo e($uri_key); ?>" style="display:none;">
    <div class="row mb-2">
        <div class="col-md-12">
            <b>Detail <?php echo e($title); ?></b>
            <button type="button" class="btn btn-sm btn-outline-danger float-end close-preview">
                <i class="bi bi-x"></i>
            </button>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 content-preview"></div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<div class="push-style">
    <?php if(isset($import_styles)): ?>
    <?php $__currentLoopData = $import_styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <link rel="stylesheet" href="<?php echo e($ist['source']); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<div class="push-script">
    <div class="offcanvas offcanvas-end" tabindex="-1" id="createForm-<?php echo e($uri_key); ?>" aria-labelledby="createForm-<?php echo e($uri_key); ?>">
        <div class="offcanvas-header border-bottom bg-secondary p-4">
            <h5 class="text-white m-0">Create New</h5>
            <button type="button" class="btn-close text-white text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <form id="form-create-<?php echo e($uri_key); ?>" action="<?php echo e($url_store); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <?php $method = "create"; ?>
                    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('backend.idev.fields.'.$field['type'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group my-2">
                            <button id="btn-for-form-create-<?php echo e($uri_key); ?>" type="button" class="btn btn-outline-secondary" onclick="softSubmit('form-create-<?php echo e($uri_key); ?>', 'list-<?php echo e($uri_key); ?>')">Submit</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="fixed-plugin">
        <a class="fixed-plugin-button text-white position-fixed px-3 py-2" data-bs-toggle="offcanvas" data-bs-target="#createForm-<?php echo e($uri_key); ?>">
            <i class="fa fa-plus py-2"> </i>
        </a>
    </div>
    <?php if(isset($import_scripts)): ?>
    <?php $__currentLoopData = $import_scripts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script src="<?php echo e($isc['source']); ?>"></script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <script>
        function updateFilter() {
            var queryParam = $("#form-filter-list-<?php echo e($uri_key); ?>").serialize();
            var currentHrefPdf = $("#export-pdf").attr('data-base-url')
            var currentHrefExcel = $("#export-excel").attr('data-base-url')

            $("#export-pdf").attr('href', currentHrefPdf + "?" + queryParam)
            $("#export-excel").attr('href', currentHrefExcel + "?" + queryParam)
            idevTable("list-<?php echo e($uri_key); ?>")
        }
    </script>
    <?php $__currentLoopData = $actionButtonViews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $abv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make($abv, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/list_drawer_ajax.blade.php ENDPATH**/ ?>