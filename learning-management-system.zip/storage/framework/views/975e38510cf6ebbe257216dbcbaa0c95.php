<div class="<?php echo e((isset($field['class']))?$field['class']:'form-group'); ?>">
    <label><?php echo e((isset($field['label']))?$field['label']:'Label '.$key); ?></label>
    <div class="field-bulktable">
        <div class="row">
            <div class="col-md-6">
                <span class="total-data-<?php echo e($field['name']); ?>"></span>
            </div>
            <div class="col-md-3">
                <span class="total-checked-<?php echo e($field['name']); ?> fw-bold">0 Checked</span>
            </div>
            <div class="col-md-3">
                <input type="text" placeholder="search..." class="form-control form-control-sm search-<?php echo e($field['name']); ?>">
            </div>
        </div>
        <table class="table idev-table table-responsive ajx-table-<?php echo e($field['name']); ?>">
            <thead>
                <tr>
                    <th>
                        # <!--input type="checkbox" class="check-all-<?php echo e($field['name']); ?>" value="flagall" -->
                    </th>
                    <?php $__currentLoopData = $field['table_headers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th style="white-space: nowrap;"><?php echo e($header); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
        <div class="paginate-<?php echo e($field['name']); ?>"></div>
        <input type="hidden" name="<?php echo e($field['name']); ?>" class="json-<?php echo e($field['name']); ?>" value="[]">
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    var ajaxUrl = "<?php echo e($field['ajaxUrl']); ?>"
    var primaryKey = "<?php echo e($field['key']); ?>"
    var stateKey = []
    $(document).ready(function() {
        getTableContent(ajaxUrl)

        // $(".check-all-<?php echo e($field['name']); ?>").change(function(){
        //     $(".check-<?php echo e($field['name']); ?>").prop('checked', $(this).prop('checked'))
        // })

        $(".search-<?php echo e($field['name']); ?>").keyup(delay(function(e) {
            var dInput = this.value;
            if (dInput.length > 3 || dInput.length == 0) {
                getTableContent(ajaxUrl + "?search=" + dInput)
            }
        }, 500))
    });

    function getTableContent(ajaxUrl) {
        $.get(ajaxUrl, function(response) {
            var headers = response.header
            var bodies = response.body
            var mHtml = ""
            var intCurrentData = 0
            $.each(bodies.data, function(index1, body) {
                var setActiveChecked = stateKey.includes(body[primaryKey]) ? "checked" : ""

                mHtml += "<tr>"
                mHtml += "<td><input type='checkbox' class='check-<?php echo e($field['name']); ?>' value='" + body[primaryKey] + "' " + setActiveChecked + "></td>"
                $.each(headers, function(index2, header) {
                    mHtml += "<td>" + body[header] + "</td>"
                })
                mHtml += "</tr>"
                intCurrentData++
            })

            var paginateLink = ""
            $.each(bodies.links, function(index, link) {
                if (link.url != null && link.label != "&laquo; Previous" && link.label != "Next &raquo;") {
                    var linkActive = link.active ? "btn-primary" : "btn-outline-primary"
                    paginateLink += "<button data-url='" + link.url + "' class='btn btn-sm btn-paginate-<?php echo e($field['name']); ?> " + linkActive + "' type='button'>" + link.label + "</button>"
                }
            })

            $(".paginate-<?php echo e($field['name']); ?>").html(paginateLink)
            $(".ajx-table-<?php echo e($field['name']); ?> tbody").html(mHtml)

            $(".btn-paginate-<?php echo e($field['name']); ?>").click(function() {
                getTableContent($(this).data('url'))
            })

            $(".check-<?php echo e($field['name']); ?>").change(function() {
                var intCurrentVal = parseInt($(this).val())
                if ($(this).prop('checked')) {
                    stateKey.push(intCurrentVal)
                } else {
                    stateKey = removeStateKey(stateKey, intCurrentVal)
                }

                $(".json-<?php echo e($field['name']); ?>").val(JSON.stringify(stateKey))
                $(".total-checked-<?php echo e($field['name']); ?>").text(stateKey.length + " Checked")
            })

            $(".total-data-<?php echo e($field['name']); ?>").text("Total : " + intCurrentData + "/" + bodies.total + " Data (s)")

        });
    }

    function removeStateKey(arr, elementToRemove) {
        return arr.filter(function(item) {
            return item !== elementToRemove;
        });
    }
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/fields/bulktable_ajax.blade.php ENDPATH**/ ?>