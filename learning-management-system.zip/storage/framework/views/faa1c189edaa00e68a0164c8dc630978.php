<?php 
$prefix_repeatable = (isset($repeatable))? true : false;
$preffix_method = (isset($method))? $method."_": "";
?>
<div class="<?php echo e((isset($field['class']))?$field['class']:'form-group'); ?>">
    <input 
        type="hidden" 
        id="<?php echo e($preffix_method); ?><?php echo e((isset($field['name']))?$field['name']:'id_'.$key); ?>" 
        name="<?php echo e((isset($field['name']))?$field['name']:'name_'.$key); ?>" 
        value="<?php echo e((isset($field['value']))?$field['value']:''); ?>" 
        class="form-control idev-form <?php if($prefix_repeatable): ?> field-repeatable <?php endif; ?>">
</div><?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/fields/hidden.blade.php ENDPATH**/ ?>