<!DOCTYPE html>
<html lang="en">

<head>
  <title><?php echo $__env->yieldPushContent("mtitle"); ?></title>
  <meta charset="utf-8" />
  <meta name="base_url" content="<?php echo e(url('')); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="description" content="<?php echo e(config('idev.app_description', 'iDev easyadmin is a laravel package to make your life more easy')); ?>" />
  <meta name="keywords" content="<?php echo e(config('idev.app_keywords', 'Laravel, idev semarang, Berry, Dashboard UI Kit, Bootstrap 5, Admin Template, Admin Dashboard, CRM, CMS, Bootstrap Admin Template')); ?>" />
  <meta name="author" content="CodedThemes" />
	<link rel="icon" href=" <?php echo e(config('idev.app_favicon', asset('easyadmin/idev/img/favicon.png'))); ?>">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" id="main-font-link" />

  <link rel="stylesheet" href="<?php echo e(asset('easyadmin/theme/default/fonts/tabler-icons.min.css')); ?>" />

  <link rel="stylesheet" href="<?php echo e(asset('easyadmin/theme/default/fonts/material.css')); ?>" />

  <link rel="stylesheet" href="<?php echo e(asset('easyadmin/theme/'.config('idev.theme','default').'/css/style.css')); ?>" id="main-style-link" />
  <link rel="stylesheet" href="<?php echo e(asset('easyadmin/theme/'.config('idev.theme','default').'/css/style-preset.css')); ?>" id="preset-style-link" />
  <link href="<?php echo e(asset('easyadmin/idev/styles.css')); ?>" rel="stylesheet" />
  <?php $__currentLoopData = config('idev.import_styles', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <link href="<?php echo e($item); ?>" rel="stylesheet" />
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</head>


<body>
  <div class="push-style-ajax"><?php echo $__env->yieldPushContent("styles"); ?></div>

  <div class="loader-bg">
    <div class="loader-track">
      <div class="loader-fill"></div>
    </div>
  </div>


  <header class="pc-header">
    <div class="m-header d-none d-lg-flex">
      <?php echo env('PROJECT_NAME', config('idev.app_name','iDev Admin') ); ?>

      <div class="pc-h-item">
        <a href="#" class="pc-head-link head-link-secondary m-0 p-1 d-none d-lg-block" id="sidebar-hide">
          <i class="ti ti-menu-2 m-1"></i>
        </a>
      </div>
    </div>
    <div class="header-wrapper">
      <div class="me-auto pc-mob-drp title-header">
        <?php echo $__env->yieldPushContent("mtitle"); ?>
      </div>

      <div class="ms-auto">
        <ul class="list-unstyled">
          <li class="pc-h-item header-mobile-collapse">
            <a href="#" class="pc-head-link head-link-secondary m-0 p-1 d-lg-none d-md-block" id="mobile-collapse">
              <i class="ti ti-menu-2 m-1"></i>
            </a>
          </li>
          <!--li class="dropdown pc-h-item">
            <a class="pc-head-link head-link-secondary dropdown-toggle arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
              <i class="ti ti-bell"></i>
            </a>
          </li-->
          <li class="dropdown pc-h-item">
            <a class="pc-head-link head-link-secondary dropdown-toggle arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
              <i class="ti ti-user"></i>
            </a>
            <div class="dropdown-menu dropdown-user-profile dropdown-menu-end pc-h-dropdown">
              <div class="dropdown-header">
                <h4>Hi, <?php echo e(Auth::user()->name); ?></h4>
                <p class="text-muted">Project Admin</p>
                <hr />
                <div class="profile-notification-scroll position-relative" style="max-height: calc(100vh - 280px)">
                  <a href="<?php echo e(url('my-account')); ?>" class="dropdown-item">
                    <i class="ti ti-settings"></i>
                    <span>Account Settings</span>
                  </a>
                  <a href="<?php echo e(route('logout')); ?>" class="dropdown-item">
                    <i class="ti ti-logout"></i>
                    <span>Logout</span>
                  </a>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </header>

  <nav class="pc-sidebar">
    <div class="navbar-wrapper">
      <div class="m-header">
        <?php echo env('PROJECT_NAME', config('idev.app_name','iDev Admin') ); ?>

      </div>
      <?php echo $__env->make('easyadmin::backend.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
  </nav>

  <?php echo $__env->yieldContent("content"); ?>

  <footer class="pc-footer">
    <div class="footer-wrapper container-fluid">
      <div class="row">
        <div class="col my-1">
          <p class="m-0"> <?php echo config('idev.copyright','Copyright &copy; iDev Semarang'); ?> </p>
        </div>
      </div>
    </div>
  </footer>

  <script src="<?php echo e(asset('easyadmin/theme/default/js/plugins/jquery-3.6.3.min.js')); ?>"></script>
  <script src="<?php echo e(asset('easyadmin/theme/default/js/plugins/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('easyadmin/theme/default/js/plugins/simplebar.min.js')); ?>"></script>
  <script src="<?php echo e(asset('easyadmin/theme/default/js/plugins/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('easyadmin/theme/default/js/plugins/sweet-alert.js')); ?>"></script>
  <script src="<?php echo e(asset('easyadmin/theme/default/js/config.js')); ?>"></script>
  <script src="<?php echo e(asset('easyadmin/theme/default/js/pcoded.js')); ?>"></script>
  <script src="<?php echo e(asset('easyadmin/idev/scripts.js')); ?>"></script>
  <?php $__currentLoopData = config('idev.import_scripts', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <script src="<?php echo e($item); ?>"></script>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div class="push-script-ajax"><?php echo $__env->yieldPushContent("scripts"); ?></div>

</body>

</html>
<?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/backend/parent.blade.php ENDPATH**/ ?>