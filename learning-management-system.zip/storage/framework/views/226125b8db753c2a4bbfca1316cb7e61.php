<?php $__env->startPush('styles'); ?>
<style>
.signature-container {
    margin-top: 15px;
}
.signature-method-selector {
    margin-bottom: 15px;
}
.signature-pad {
    border: 2px solid #ddd;
    border-radius: 8px;
    background: white;
    cursor: crosshair;
    width: 100%
}
.signature-actions {
    margin-top: 10px;
    text-align: center;
}
.signature-actions .btn {
    margin: 0 5px;
}
.current-signature {
    max-width: 150px;
    max-height: 80px;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 5px;
}
.signature-preview {
    margin-top: 10px;
    text-align: center;
}
.upload-zone {
    border: 2px dashed #ddd;
    border-radius: 8px;
    padding: 20px;
    text-align: center;
    background: #f9f9f9;
}

@media (max-width: 576px) {
    .svg-container {
        max-width: 100%;
        height: auto;
    }
}
</style>
<?php $__env->stopPush(); ?>
<!-- Custom Signature Field -->
    <div class="<?php echo e($field['class'] ?? 'col-md-12 my-2'); ?>">
        <label class="form-label fw-bold"><?php echo e($field['label']); ?></label>

        <!-- Current Signature Display -->
        <?php if(!empty($field['value'])): ?>
            <div class="current-signature-display mb-3">
                <small class="text-muted">Current Signature:</small>
                <br>
                <img src="<?php echo e($field['value']); ?>" alt="Current Signature" class="current-signature">
            </div>
        <?php endif; ?>

        <!-- Signature Creation Options -->
        <div class="signature-container">
            <div class="signature-method-selector">
                <div class="d-flex justify-content-center gap-3">
                    <label class="form-check-label d-flex align-items-center">
                        <input type="radio" name="signature_method" value="draw" class="form-check-input me-2" checked> 
                        <span>✏️ Draw Signature</span>
                    </label>
                    <label class="form-check-label d-flex align-items-center">
                        <input type="radio" name="signature_method" value="upload" class="form-check-input me-2"> 
                        <span>📁 Upload Image</span>
                    </label>
                </div>
        </div>
                        
        <!-- Draw Signature Section -->
        <div id="draw-signature-section">
            <div class="text-center mb-2">
                <small class="text-muted">Draw your signature in the box below</small>
            </div>
            <canvas id="signature-pad" class="signature-pad mx-auto d-block" width="400" height="200"></canvas>
            <div class="signature-actions">
                <button type="button" class="btn btn-sm btn-outline-secondary" onclick="clearSignature()">
                    <i class="ti ti-refresh"></i> Clear
                </button>
                <button type="button" class="btn btn-sm btn-primary" onclick="saveSignature()">
                    <i class="ti ti-device-floppy"></i> Save as SVG
                </button>
                <button type="button" class="btn btn-sm btn-info" onclick="previewSignature()">
                    <i class="ti ti-eye"></i> Preview
                </button>
            </div>
            <div id="signature-status" class="mt-2 text-center"></div>
            <div id="signature-preview-draw" class="signature-preview"></div>
        </div>
                        
        <!-- Upload Signature Section -->
        <div id="upload-signature-section" style="display: none;">
            <div class="upload-zone">
                <input type="file" name="signature_file" class="form-control mb-2" accept="image/*" onchange="previewUploadedSignature(this)">
                    <small class="text-muted">
                        <i class="ti ti-info-circle"></i> 
                        Upload PNG, JPG, or GIF (max 2MB)
                    </small>
            </div>
            <div id="upload-preview" class="signature-preview"></div>
        </div>
    </div>
    
    <!-- Hidden input to store signature data -->
    <input type="hidden" name="signature_data" id="signature-data"><?php /**PATH C:\laragon\www\learning-management-system\resources\views/backend/idev/fields/signature.blade.php ENDPATH**/ ?>