<div class="modal fade" tabindex="-1" role="dialog" id="modalDelete">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Konfirmasi</h5>
            </div>
            <div class="modal-body">
                <p>Are you sure, want to delete this data? <span id='attrDelete'></span></p>
                <form id="form-delete-<?php echo e($uri_key); ?>" action="#" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <button type="button" 
                        class="btn btn-sm btn-outline-primary"                             
                        onclick="softSubmit('form-delete-<?php echo e($uri_key); ?>', 'list-<?php echo e($uri_key); ?>')">Yes</button>
                    <button type="button" class="btn btn-sm btn-outline-danger" data-bs-dismiss="modal">No</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function setDelete(id) {
        var uriKey = "<?php echo e($uri_key); ?>"
        var uriDelete = "<?php echo e(url($uri_key)); ?>/"+id
        $("#form-delete-" + uriKey).attr('action', uriDelete)
    }
</script><?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/buttons/delete.blade.php ENDPATH**/ ?>