
<div class="navbar-content">
    <ul class="pc-navbar">
        <?php $__currentLoopData = (new App\Helpers\Sidebar())->generate(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($menu['visibility']) && $menu['visibility']): ?>
        <li class="pc-item sidebar-<?php echo e($menu['base_key']); ?> <?php if(sizeof($menu['childrens']) > 0): ?> pc-hasmenu <?php endif; ?>">
            <a class="pc-link 
                <?php if(Route::has($menu['key'])): ?> <?php if(strpos(URL::current(), route($menu['key'])) !==false ): ?> active <?php endif; ?> <?php endif; ?>
                <?php if(sizeof($menu['childrens']) > 0): ?>
                sidebar-link
                <?php endif; ?>" <?php if(sizeof($menu['childrens'])> 0): ?>
                href="#"
                <?php else: ?>
                href="<?php if(Route::has($menu['key'])): ?> <?php echo e(route($menu['key'])); ?> <?php else: ?> <?php echo e($menu['url']); ?><?php endif; ?>"
                <?php endif; ?>

                <?php if(isset($menu['ajax_load']) && $menu['ajax_load'] == true): ?>
                onclick="loadPage(event,'<?php echo e($menu['base_key']); ?>','<?php if(Route::has($menu['key'])): ?> <?php echo e(route($menu['key'])); ?> <?php endif; ?>')"
                <?php endif; ?>
                >
                <span class="pc-micon"><i class="<?php echo e($menu['icon']); ?>"></i></span>
                <span class="pc-mtext">
                    <?php echo e($menu['name']); ?>

                </span>
                <?php if(sizeof($menu['childrens']) > 0): ?>
                <span class="pc-arrow">
                    <i class="ti ti-chevron-right"></i>
                </span>
                <?php endif; ?>
            </a>

            <?php if(sizeof($menu['childrens']) > 0): ?>
            <ul class="pc-submenu">
            <?php $__currentLoopData = $menu['childrens']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($cm['visibility']) && $cm['visibility']): ?>
                <li class="pc-item">
                    <a href="<?php if(Route::has($cm['key'])): ?> <?php echo e(route($cm['key'])); ?> <?php endif; ?>" class="pc-link"><?php echo e($cm['name']); ?></a>
                </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>

        </li>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>  
</div>


<?php $__env->startPush('scripts'); ?>
<script>
    var uriKey = ''

    function loadPage(e, uriKey, url) {
        e.preventDefault()
        var url = url.replaceAll(" ", "")

        $(".page-from-ajax").css("filter", 'blur(2px)')
        $(".nav-link").removeClass("active")
        $(".sidebar-" + uriKey+" .nav-link").addClass("active")
        changeUrl(uriKey)
        $.get(url, {
            from_ajax: true
        }, function(response) {
            $(".page-from-ajax").html(response)

            $(".current-title-ajax").text($(".current-title").text())
            $(".current-title").remove()
            $(".page-from-ajax").css("filter", 'blur(0px)')
            updateContent(uriKey)
        });
        uriKey = uriKey
    }

    function updateContent(uriKey) {
        var addHtmlScript = ""
        $('.push-script').each(function(i, obj) {
            addHtmlScript += $(this).html()
        });
        $('.push-script-ajax').html(addHtmlScript);
        $('.push-script').remove();

        var addHtmlStyle = ""
        $('.push-style').each(function(i, obj) {
            addHtmlStyle += $(this).html()
        });
        $('.push-style-ajax').html(addHtmlStyle);
        $('.push-style').remove();

        if ($(".idev-actionbutton").children().length == 0) {
            $("#dropdownMoreTopButton").remove()
            $(".idev-actionbutton").remove()
        }
        idevTable("list-" + uriKey)
        $('form input').on('keypress', function(e) {
            return e.which !== 13;
        });
        $(".search-list-" + uriKey).keyup(delay(function(e) {
            var dInput = this.value;
            if (dInput.length > 3 || dInput.length == 0) {
                $(".current-paginate-" + uriKey).val(1)
                $(".search-list-" + uriKey).val(dInput)
                updateFilter()
            }
        }, 500))
    }

    function changeUrl(url) {
        var new_url = url;
        window.history.pushState("data", "Title", new_url);
        document.title = url;
    }

</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/backend/sidebar.blade.php ENDPATH**/ ?>