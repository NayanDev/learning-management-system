<?php 
$prefix_repeatable = (isset($repeatable))? true : false;
$preffix_method = (isset($method))? $method."_": "";
?>
<div class="<?php echo e((isset($field['class']))?$field['class']:'form-group'); ?>">
    <label><?php echo e((isset($field['label']))?$field['label']:'Label '.$key); ?></label>
    <br>
    <?php if(isset($field['value'])): ?>
    <img src="<?php echo e($field['value']); ?>" class="img-thumbnail img-fluid thumb_<?php echo e((isset($field['name']))?$field['name']:'id_'.$key); ?>" alt="">
    <br>
    <?php endif; ?>
    <input type="file" accept="image/png, image/gif, image/jpeg" id="<?php echo e($preffix_method); ?><?php echo e((isset($field['name']))?$field['name']:'id_'.$key); ?>" name="<?php echo e((isset($field['name']))?$field['name']:'name_'.$key); ?>" class="form-control idev-validation" placeholder="Image">
</div><?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/fields/image.blade.php ENDPATH**/ ?>