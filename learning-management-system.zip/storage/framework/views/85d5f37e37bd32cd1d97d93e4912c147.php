<?php 
$prefix_repeatable = (isset($repeatable))? true : false;
$preffix_method = (isset($field['method']))? $field['method']."_": "";
?>
<div class="<?php echo e((isset($field['class']))?$field['class']:'form-group'); ?>">
    <label><?php echo e((isset($field['label']))?$field['label']:'Label '.$key); ?></label>
    <div class="<?php echo e($preffix_method); ?>repeatable-sections">
        <?php 
        $field_count = 0;
        $enable_action = $field['enable_action'];
        $row_count = sizeof($field['html_fields']);
        ?>
       
        <div id="<?php echo e($preffix_method); ?>repeatable-0" class="row <?php echo e($preffix_method); ?>field-sections">

            <?php $__currentLoopData = $field['html_fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $child_fields): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $field_item = $child_fields;
            $repeatable = true;
            $field_item['name'] = $field_item['name']."[]";
            ?>
            <?php if(View::exists('backend.idev.fields.'.$field_item['type'])): ?>
                <?php echo $__env->make('backend.idev.fields.'.$field_item['type'], ['field' => $field_item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('easyadmin::backend.idev.fields.'.$field_item['type'], ['field' => $field_item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($enable_action): ?>
            <div class="col-md-1 remove-section">
                <button type='button' class='btn btn-sm btn-circle btn-danger my-4 text-white' onclick='removeRow("<?php echo e($preffix_method); ?>",0)'>
                    <i class='ti ti-minus' data-toggle='tooltip' data-placement='top' title='Remove'> </i>
                </button>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if($enable_action): ?>
    <div class="row">
        <div class="col-md-4">
            <button type="button" class="btn btn-sm btn-secondary my-2 text-white" onclick="addRow('<?php echo e($preffix_method); ?>')">
                <i class="fa fa-plus" data-toggle="tooltip" data-placement="top" title="Add"> </i> 1 ITEM
            </button>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->startPush('styles'); ?>
    <style>
        .btn-circle{
            border-radius: 50%;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    function addRow(preffixMethod) {
        var epochMilliseconds = Date.now();
        var epochSeconds = Math.floor(epochMilliseconds / 1000);

        // Ambil container yang spesifik
        var $container = $('.'+preffixMethod+'repeatable-sections');
        
        // Ambil hanya direct child terakhir dengan class field-sections
        var $lastRow = $container.children('.'+preffixMethod+'field-sections').last();
        
        // Clone row
        var $clonedRow = $lastRow.clone();
        
        // Set ID baru untuk cloned row
        $clonedRow.attr('id', preffixMethod+'repeatable-'+epochSeconds);
        
        // Clear semua input values di cloned row
        $clonedRow.find('input:not([type="radio"]):not([type="checkbox"]), textarea, select').val('');
        $clonedRow.find('input[type="radio"], input[type="checkbox"]').prop('checked', false);
        
        // Append ke container
        $clonedRow.appendTo($container);
        
        // Remove ID dari form jika ada
        $clonedRow.find(".idev-form").attr("id", null);

        // Update button remove di row yang baru
        var htmlRemove = "<button type='button' class='btn btn-sm btn-circle btn-danger my-4 text-white' onclick='removeRow(\""+preffixMethod+"\","+epochSeconds+")'>";
        htmlRemove += "<i class='ti ti-minus' data-toggle='tooltip' data-placement='top' title='Remove'> </i>";
        htmlRemove += "</button>";
        $clonedRow.find('.remove-section').html(htmlRemove);
    }

    function removeRow(preffixMethod, index) {
        var $container = $('.'+preffixMethod+'repeatable-sections');
        var rowCount = $container.children('.'+preffixMethod+'field-sections').length;
        
        // Jangan hapus jika hanya ada 1 row
        if(rowCount > 1) {
            $("#"+preffixMethod+"repeatable-"+index).remove();
        } else {
            alert('Minimal harus ada 1 item!');
        }
    }<?php /**PATH C:\laragon\www\learning-management-system\resources\views/backend/idev/fields/repeatable.blade.php ENDPATH**/ ?>