<?php 
$prefix_repeatable = (isset($repeatable))? true : false;
$preffix_method = (isset($field['method']))? $field['method']."_": ""; // gunakan $field['method']
?>
<div class="<?php echo e((isset($field['class']))?$field['class']:'form-group'); ?>">
    <label><?php echo e((isset($field['label']))?$field['label']:'Label '.$key); ?></label>
    <div class="<?php echo e($preffix_method); ?>repeatable-sections">
        <?php 
        $enable_action = $field['enable_action'];
        ?>
        <div id="<?php echo e($preffix_method); ?>repeatable-0" class="row <?php echo e($preffix_method); ?>field-sections">
            <?php $__currentLoopData = $field['html_fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $child_fields): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $child = $child_fields; $repeatable = true; $child['name'] = $child['name'].'[]';
            ?>
            <?php if(View::exists('backend.idev.fields.'.$child['type'])): ?>
                <?php echo $__env->make('backend.idev.fields.'.$child['type'], ['field' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('easyadmin::backend.idev.fields.'.$child['type'], ['field' => $child], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($enable_action): ?>
            <div class="col-md-1 remove-section">
                <button type='button' class='btn btn-sm btn-circle btn-danger my-4 text-white' onclick='remove("<?php echo e($preffix_method); ?>",0)'>
                    <i class='ti ti-minus'></i>
                </button>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if($enable_action): ?>
    <div class="row">
        <div class="col-md-4">
            <button type="button" class="btn btn-sm btn-secondary my-2 text-white" onclick="add('<?php echo e($preffix_method); ?>')">
                <i class="fa fa-plus"></i> 1 ITEM
            </button>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    function add(preffixMethod) {
        var epochSeconds = Math.floor(Date.now()/1000);

        // target hanya container yang benar (direct child saja)
        var $container = $('.'+preffixMethod+'repeatable-sections');
        var $lastRow = $container.children('.'+preffixMethod+'field-sections').last();

        $lastRow.attr('id', preffixMethod+'repeatable-'+epochSeconds);

        var $clone = $lastRow.clone();
        $clone.find('input:not([type="radio"]):not([type="checkbox"]), textarea, select').val('');
        $clone.find('input[type="radio"], input[type="checkbox"]').prop('checked', false);

        $clone.appendTo($container);

        var htmlRemove = "<button type='button' class='btn btn-sm btn-circle btn-danger my-4 text-white' onclick='remove(\""+preffixMethod+"\","+epochSeconds+")'><i class=\"ti ti-minus\"></i></button>";
        $clone.find('.remove-section').html(htmlRemove);
    }

    function remove(preffixMethod, index) {
        $("#"+preffixMethod+"repeatable-"+index).remove();
    }
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/fields/repeatable.blade.php ENDPATH**/ ?>