<?php $__env->startPush('mtitle'); ?>
<?php echo e($title); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection("contentfrontend"); ?>
<div class="auth-main">
    <div class="auth-wrapper v3">
        <div class="auth-form">
            <div class="card my-5">
                <div class="card-body">

                    <a href="#" class="d-flex justify-content-center">
                        <img src="<?php echo e(config('idev.app_logo', asset('easyadmin/idev/img/logo-idev.png'))); ?>">
                    </a>
                    <div class="row">
                        <div class="d-flex justify-content-center">
                            <div class="auth-header">
                                <!-- <h2 class="text-dark my-2"><b>Please Login</b></h2> -->
                            </div>
                        </div>
                    </div>
                    
                    <form id="form-login" action="<?php echo e(url('login')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="email" class="form-control" id="create_email" name="email" placeholder="Email address / Username" />
                            <label for="floatingInput">Email address / Username</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" id="create_password" name="password" placeholder="Password" />
                            <label for="floatingInput">Password</label>
                        </div>
                        
                        <div class="d-grid mt-4">
                            <button type="button" class="btn btn-primary-idev" id="btn-for-form-login" onclick="submitAfterValid('form-login')">Sign In</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('fescripts'); ?>
<script>
    var input = document.getElementById("create_password");

    input.addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
            event.preventDefault();
            submitAfterValid('form-login')
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("easyadmin::frontend.parent", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/frontend/login.blade.php ENDPATH**/ ?>