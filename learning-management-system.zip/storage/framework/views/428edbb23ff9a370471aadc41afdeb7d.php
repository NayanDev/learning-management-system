<?php
    $preffix_method = isset($method) ? $method . '_' : '';
    $passFormId = (isset($field['name']) ? $field['name'] : 'id_' . $key);
    $passFormId = $preffix_method . $passFormId;
?>

<div class="<?php echo e(isset($field['class']) ? $field['class'] : 'form-group'); ?>">
    <label><?php echo e(isset($field['label']) ? $field['label'] : 'Label ' . $key); ?></label>
    <div class="input-group">
        <input type="password" id="<?php echo e($passFormId); ?>"
            name="<?php echo e(isset($field['name']) ? $field['name'] : 'name_' . $key); ?>"
            value="<?php echo e(isset($field['value']) ? $field['value'] : ''); ?>" class="form-control idev-form" autocomplete="off">
        <button type="button" id="sh_<?php echo e($passFormId); ?>" class="btn btn-outline-secondary toggle-password" data-target="<?php echo e($passFormId); ?>">
            Show
        </button>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const btn = document.getElementById('sh_<?php echo e($passFormId); ?>');
        btn.addEventListener('click', function() {
            const input = document.getElementById(this.getAttribute('data-target'));
            console.log(input);

            if (input.type === 'password') {
                input.type = 'text';
                this.textContent = 'Hide';
            } else {
                input.type = 'password';
                this.textContent = 'Show';
            }
        });
    });
</script>
<?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/fields/password.blade.php ENDPATH**/ ?>