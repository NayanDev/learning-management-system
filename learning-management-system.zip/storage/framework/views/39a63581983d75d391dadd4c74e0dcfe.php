<?php 
$prefix_repeatable = (isset($repeatable))? true : false;
$preffix_method = (isset($method))? $method."_": "";
?>
<div class="<?php echo e((isset($field['class']))?$field['class']:'form-group'); ?>">
    <label><?php echo e((isset($field['label']))?$field['label']:'Label '.$key); ?> 
        <?php if(isset($field['required']) && $field['required']): ?>
        <small class="text-danger">*</small>
        <?php endif; ?>
    </label>
    <textarea id="<?php echo e($preffix_method); ?><?php echo e((isset($field['name']))?str_replace("[]","",$field['name']):'id_'.$key); ?>" 
        name="<?php echo e(isset($field['name']) ? $field['name'] : 'name_' . $key); ?>"
        value="<?php echo e(isset($field['value']) ? $field['value'] : ''); ?>" cols="30" rows="2"
        class="form-control idev-form <?php if($prefix_repeatable): ?> field-repeatable <?php endif; ?>"><?php echo e(isset($field['value']) ? $field['value'] : ''); ?></textarea>
</div><?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/fields/textarea.blade.php ENDPATH**/ ?>