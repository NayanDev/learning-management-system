
<?php $__env->startSection("content"); ?>
<?php $__env->startPush('mtitle'); ?>
<?php echo e($title); ?>

<?php $__env->stopPush(); ?>
<div class="pc-container" id="section-list-<?php echo e($uri_key); ?>">
    <div class="pc-content">
        <div class="page-header">
            <div class="page-block">
                <?php if(isset($headerLayout)): ?>
                    <?php echo $__env->make('backend.idev.parts.'.$headerLayout.'', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php else: ?>
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <span class="count-total-list-<?php echo e($uri_key); ?> float-end mt-2">0 Data</span>
                        </div>
                        <?php if(in_array('create', $permissions)): ?>
                            <a class="btn btn-secondary float-end text-white mx-1" data-bs-toggle="offcanvas" data-bs-target="#createForm-<?php echo e($uri_key); ?>">
                                Create
                            </a>
                        
                            <?php if(request('event_id')): ?>
                                <button class="btn btn-danger float-end text-white mx-1" onclick="generateUser()">
                                    <i class="ti ti-settings"></i>  Generate User
                                </button>
                                <a href="<?php echo e(route('set.account', ['id' => request('event_id')])); ?>" class="btn btn-success float-end text-white mx-1">
                                    <i class="ti ti-users"></i>  User Account
                                </a>
                            <?php endif; ?>
                        
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-body p-3">
                        <div class="row">
                            <div class="col-8 col-md-6">
                                <?php $__currentLoopData = $more_actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(isset($ma['key']) && in_array($ma['key'], $permissions)): ?>
                                <?php echo $ma['html_button']; ?>

                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="col-4 col-md-6">
                            </div>
                            <div class="col-md-12">
                                <form id="form-filter-list-<?php echo e($uri_key); ?>" action="<?php echo e($uri_list_api); ?>" method="get">
                                    <div class="row my-3">
                                        <div class="col-md-2">
                                            <small for="">Search</small>
                                            <div class="form-group">
                                                <input class="form-control search-list-<?php echo e($uri_key); ?>" name="search" placeholder="Type for search...">
                                                <input type="hidden" name="route_name" class="route-name-<?php echo e($uri_key); ?>" value="<?php echo e($uri_key); ?>">
                                                <input type="hidden" name="page" class="current-paginate-<?php echo e($uri_key); ?>">
                                                <input type="hidden" name="order" class="current-order-<?php echo e($uri_key); ?>">
                                                <input type="hidden" name="manydatas" class="current-manydatas-<?php echo e($uri_key); ?>" value="10">
                                                <input type="hidden" name="order_state" class="current-order-state-<?php echo e($uri_key); ?>" value="ASC">
                                            </div>
                                        </div>
                                        <?php if(isset($filters)): ?>
                                        <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(View::exists('backend.idev.filters.'.$filter['type'])): ?>
                                                <?php echo $__env->make('backend.idev.filters.'.$filter['type'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                            <?php else: ?>
                                                <?php echo $__env->make('easyadmin::backend.idev.filters.'.$filter['type'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="table-responsive p-0">
                            <table id="table-list-<?php echo e($uri_key); ?>" class="table table-hover">
                                <thead>
                                    <tr>
                                        <?php $__currentLoopData = $table_headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $header_name = $header['name'];
                                        $header_column = $header['column'];
                                        ?>
                                        <?php if($header['order']): ?>
                                        <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7" style="white-space: nowrap;"><?php echo e($header_name); ?>

                                            <button class="btn btn-sm btn-link" onclick="orderBy('list-<?php echo e($uri_key); ?>','<?php echo e($header_column); ?>')"><i class="ti ti-arrow-up"></i></button>
                                        </th>
                                        <?php else: ?>
                                        <th style="white-space: nowrap;"><?php echo e($header_name); ?>

                                        </th>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <th class="col-action"></th>
                                    </tr>
                                </thead>
                                <tbody></tbody>
                            </table>
                            <div class="row">
                                <div class="col-md-1 col-lg-1 col-2">
                                    <select class="form-control form-control-sm" id="manydatas-show-<?php echo e($uri_key); ?>">
                                        <?php $__currentLoopData = ['10', '20', '50', '100', 'All']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $showData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($showData); ?>"><?php echo e($showData); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-11">
                                    <div id="paginate-list-<?php echo e($uri_key); ?>"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="pc-container" id="section-preview-<?php echo e($uri_key); ?>" style="display:none;">
    <div class="pc-content">
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                           <b>Detail <?php echo e($title); ?></b> 
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-danger float-end close-preview">
                            Close
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-md-12 content-preview"></div>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<?php if(isset($import_styles)): ?>
<?php $__currentLoopData = $import_styles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<link rel="stylesheet" href="<?php echo e($ist['source']); ?>">
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<?php if(in_array('create', $permissions)): ?>
<div class="offcanvas offcanvas-end <?php if(isset($drawerExtraClass)): ?> <?php echo e($drawerExtraClass); ?> <?php endif; ?>" tabindex="-1" id="createForm-<?php echo e($uri_key); ?>" aria-labelledby="createForm-<?php echo e($uri_key); ?>">
    <div class="offcanvas-header border-bottom bg-secondary p-4">
        <h5 class="text-white m-0">Create New</h5>
        <button type="button" class="btn-close text-white text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
        <form id="form-create-<?php echo e($uri_key); ?>" action="<?php echo e($url_store); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <?php $method = "create"; ?>
                <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(View::exists('backend.idev.fields.'.$field['type'])): ?>
                    <?php echo $__env->make('backend.idev.fields.'.$field['type'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php else: ?>
                    <?php echo $__env->make('easyadmin::backend.idev.fields.'.$field['type'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group my-2">
                        <button id="btn-for-form-create-<?php echo e($uri_key); ?>" type="button" class="btn btn-outline-secondary" onclick="softSubmit('form-create-<?php echo e($uri_key); ?>', 'list-<?php echo e($uri_key); ?>')">Submit</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<?php if(isset($import_scripts)): ?>
<?php $__currentLoopData = $import_scripts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<script src="<?php echo e($isc['source']); ?>"></script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<script>
    $(document).ready(function() {
        if ($(".idev-actionbutton").children().length == 0) {
            $("#dropdownMoreTopButton").remove()
            $(".idev-actionbutton").remove()
        }
        idevTable("list-<?php echo e($uri_key); ?>")
        $('form input').on('keypress', function(e) {
            return e.which !== 13;
        });
    })
    $(".search-list-<?php echo e($uri_key); ?>").keyup(delay(function(e) {
        var dInput = this.value;
        if (dInput.length > 3 || dInput.length == 0) {
            $(".current-paginate-<?php echo e($uri_key); ?>").val(1)
            $(".search-list-<?php echo e($uri_key); ?>").val(dInput)
            updateFilter()
        }
    }, 500))

    $("#manydatas-show-<?php echo e($uri_key); ?>").change(function(){
        $(".current-manydatas-<?php echo e($uri_key); ?>").val($(this).val())
        idevTable("list-<?php echo e($uri_key); ?>")
    });

    function updateFilter() {
        var queryParam = $("#form-filter-list-<?php echo e($uri_key); ?>").serialize();
        var currentHrefPdf = $("#export-pdf").attr('data-base-url')
        var currentHrefExcel = $("#export-excel").attr('data-base-url')

        $("#export-pdf").attr('href', currentHrefPdf + "?" + queryParam)
        $("#export-excel").attr('href', currentHrefExcel + "?" + queryParam)
        idevTable("list-<?php echo e($uri_key); ?>")
    }


    function generateUser() {
        const urlParams = new URLSearchParams(window.location.search);
        const eventId = urlParams.get('event_id');

        if (!eventId) {
            Swal.fire({
                icon: 'error',
                title: 'Gagal!',
                text: '❌ event_id tidak ditemukan di URL!'
            });
            return;
        }

        Swal.fire({
            title: 'Yakin ingin generate user?',
            text: 'User akan dibuat berdasarkan data peserta.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya, lanjutkan',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (!result.isConfirmed) return;

            Swal.fire({
                title: 'Sedang diproses...',
                text: 'Mohon tunggu beberapa saat.',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });

            fetch(`/participant-generate-user/${eventId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                }
            })
            .then(async response => {
                let data = null;
                try {
                    data = await response.json();
                } catch (e) {
                    console.warn('Response bukan JSON:', e);
                }

                Swal.close(); // Tutup loading

                if (!response.ok) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal!',
                        text: data?.message || 'Terjadi kesalahan server.'
                    });
                    return;
                }

                if (!data) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal!',
                        text: '❌ Server tidak mengirim data.'
                    });
                    return;
                }

                Swal.fire({
                    icon: 'success',
                    title: 'Berhasil!',
                    html: `✅ Berhasil buat <b>${data.created}</b> user.<br>⏩ Dilewati: <b>${data.skipped}</b>`,
                    confirmButtonText: 'OK'
                }).then(() => {
                    location.reload();
                });
            })
            .catch(error => {
                Swal.close();
                console.error('Fetch error:', error);
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: '❌ Fetch error: ' + error.message
                });
            });
        });
    }
</script>
<?php $__currentLoopData = $actionButtonViews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $abv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make($abv, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("easyadmin::backend.parent", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\learning-management-system\resources\views/backend/idev/list_drawer_participant.blade.php ENDPATH**/ ?>