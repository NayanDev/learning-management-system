<div class="<?php echo e((isset($field['class']))?$field['class']:'form-group'); ?>">
    <label><?php echo e((isset($field['label']))?$field['label']:'Label '.$key); ?></label>
    <table class="table idev-table table-responsive">
        <thead>
            <tr>
                <?php $__currentLoopData = $field['table_headers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $header_column = $header['name'];
                ?>
                <th style="white-space: nowrap;"><?php echo e($header_column); ?> <button class="btn btn-sm btn-link" <?php if($header['order']): ?> onclick="orderBy('list','<?php echo e($header_column); ?>')" <?php endif; ?>><i class="fa fa-sort"></i></button></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $field['body_datas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <?php $__currentLoopData = $field['table_headers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $hd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key2 == 0): ?>
                <td>
                    <input 
                        type="checkbox" 
                        name="<?php echo e($field['name']); ?>[]" 
                        value="<?php echo e($bd->id); ?>"
                        <?php if(in_array($bd->id, $field['value'])): ?>
                        checked
                        <?php endif; ?>
                    >
                </td>
                <?php else: ?>
                <td><?php echo $bd->{$hd['column']}; ?></td>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/fields/bulktable.blade.php ENDPATH**/ ?>