<?php 
$prefix_repeatable = (isset($repeatable))? true : false;
$preffix_method = (isset($method))? $method."_": "";
$accept = "*";
if (isset($field['accept'])) {
    $accept = $field['accept'];
}
?>
<div class="<?php echo e((isset($field['class']))?$field['class']:'form-group'); ?>">
    <label><?php echo e((isset($field['label']))?$field['label']:'Label '.$key); ?></label>
    <br>
  
    <input type="file" accept="<?php echo e($accept); ?>" id="<?php echo e($preffix_method); ?><?php echo e((isset($field['name']))?$field['name']:'id_'.$key); ?>" name="<?php echo e((isset($field['name']))?$field['name']:'name_'.$key); ?>" class="form-control idev-validation" placeholder="Upload File">
    <?php if(isset($field['value']) && $field['value'] != ""): ?>
    <a href="<?php echo e($field['value']); ?>" class="fiu_<?php echo e((isset($field['name']))?$field['name']:'id_'.$key); ?>"> <i class="ti ti-link"></i>Link To File</a>
    <br>
    <?php endif; ?>
</div><?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/fields/upload.blade.php ENDPATH**/ ?>