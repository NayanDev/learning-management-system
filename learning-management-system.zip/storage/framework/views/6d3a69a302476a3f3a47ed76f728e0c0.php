<?php
    $letterNumb = $event->letter_number ?? '-';
    $workshop = ucwords(strtolower($event->workshop->name ?? '-'));
    $divisi = ucwords(strtolower($event->divisi ?? '-'));
    $location = ucwords(strtolower($event->location ?? '-'));
    $day = \Carbon\Carbon::parse($event->start_date)->isoFormat('dddd');
    $date = \Carbon\Carbon::parse($event->start_date)->translatedFormat('d F Y') ?? '-';;
    $clock = \Carbon\Carbon::parse($event->start_date)->format('H:i') ?? '-';
    $speaker = $event->speaker ?? '-';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Daftar Hadir Pelatihan</title>
    <link rel="icon" href=" <?php echo e(config('idev.app_favicon', asset('easyadmin/idev/img/favicon.png'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('custom/css/report.css')); ?>">
</head>
<body>
    <div class="letterhead">
            <img src="<?php echo e(asset('easyadmin/idev/img/kop-dokumen.png')); ?>" alt="PT Sampharindo">
            <h3  style="border: 1px solid black;padding:25px 10px 25px 25px;">DAFTAR HADIR PELATIHAN</h3>
        </div>
        <div class="info-section">
            <table class="no-border" style="width:100%;">
                <tr>
                    <td class="text-start no-border" width="10%">Nomor</td>
                    <td width="3%" class="no-border">:</td>
                    <td class="text-start no-border"><?php echo e($letterNumb); ?></td>
                </tr>
                <tr>
                    <td class="text-start no-border">Hari / Tgl</td>
                    <td width="3%" class="no-border">:</td>
                    <td class="text-start no-border"><?php echo e($day); ?>, <?php echo e($date); ?> <span style="float: right">Jam : <?php echo e($clock); ?> WIB - Selesai</span></td>
                </tr>
                <tr>
                    <td class="text-start no-border">Tempat</td>
                    <td width="3%" class="no-border">:</td>
                    <td class="text-start no-border"><?php echo e($location); ?></td>
                </tr>
                <tr>
                    <td class="text-start no-border" style="vertical-align: top">Pembicara</td>
                    <td width="3%" style="vertical-align: top" class="no-border">:</td>
                    <td class="text-start no-border no-border">
                        <?php echo e($speaker); ?>

                    </td>
                </tr>
            </table>
        </div>
        <p>Pokok Bahasan: <?php echo e($workshop); ?></p>

        <table>
            <thead>
                <tr>
                    <th width="5%">No</th>
                    <th width="30%">Nama</th>
                    <th  width="20%">Divisi / Bagian</th>
                    <th>Tanda Tangan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->iteration % 2 === 0): ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>    
                            <td class="text-start"><?php echo e($participant->name); ?></td>    
                            <td><?php echo e($participant->divisi); ?></td>    
                            <td style="text-align: center;position: relative;">
                                <?php if(($participant->event->end_date < now()) && ($participant->attendance?->date_present === null)): ?>
                                    <?php echo e($loop->iteration); ?>.<span style="display: inline-block;position: absolute;left:52%;">Tidak Hadir</span>
                                <?php else: ?>
                                    <?php echo e($loop->iteration); ?>.<img src="<?php echo e(asset('storage/signature/'.($participant->attendance?->signready->signature ?? 'default.svg'))); ?>" style="position: absolute;top:-10;left:120;" alt=" " height="70">
                                <?php endif; ?>
                            </td>    
                        </tr>
                    <?php else: ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>    
                            <td class="text-start"><?php echo e($participant->name); ?></td>    
                            <td><?php echo e($participant->divisi); ?></td>    
                            <td style="text-align: left;position: relative;">
                                <?php if(($participant->event->end_date < now()) && ($participant->attendance?->date_present === null)): ?>
                                    <?php echo e($loop->iteration); ?>.Tidak Hadir
                                <?php else: ?>
                                <?php echo e($loop->iteration); ?>.<img src="<?php echo e(asset('storage/signature/'.($participant->attendance?->signready->signature ?? 'default.svg'))); ?>" style="position: absolute;top:-10;left:-10;" alt=" " height="70">
                                <?php endif; ?>
                            </td>    
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                          
            </tbody>
        </table>
    <br>
    <table class="no-border" style="width:100%;">
        <tr>
            <?php if($event->instructor === 'internal'): ?>
                <?php if($event?->trainers->count() === 1): ?>
                    <?php $__currentLoopData = $event->trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="no-border text-left" style="width:25%;">
                            <?php if($loop->iteration === 1): ?>
                                Semarang, <?php echo e($event->created_date ? \Carbon\Carbon::parse($event->created_date)->translatedFormat('d F Y') : now()->translatedFormat('d F Y')); ?>

                            <?php endif; ?>
                            <br>
                            Pembicara
                            <br><br>
                            <div style="display: flex; justify-content: center;">
                                <div style="display: inline-block;">
                                    <?php echo DNS2D::getBarcodeHTML( $trainer?->user->name . "\n" . 'STAFF ' . $trainer->user->divisi . "\n" . '(ini adalah dokumen resmi dan sah)', 'QRCODE', 1, 1 ); ?>

                                </div>
                            </div>
                            <br>
                            <u><strong><?php echo e($trainer->user->name ?? '-'); ?></strong></u>
                            <br>
                            <span>STAFF <?php echo e($trainer->user->divisi ?? '-'); ?></span>
                        </td>
                        <td class="no-border" style="width:75%;"></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php elseif($event?->trainers->count() === 2): ?>
                    <?php $__currentLoopData = $event->trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="no-border text-center" style="width:50%;">
                            <?php if($loop->iteration === 1): ?>
                                Semarang, <?php echo e($event->created_date ? \Carbon\Carbon::parse($event->created_date)->translatedFormat('d F Y') : now()->translatedFormat('d F Y')); ?>

                            <?php endif; ?>
                            <br>
                            Pembicara <?php echo e($loop->iteration); ?>

                            <br><br>
                            <div style="display: flex; justify-content: center;">
                                <div style="display: inline-block;">
                                    <?php echo DNS2D::getBarcodeHTML( $trainer->user->name . "\n" . 'STAFF ' . $trainer->user->divisi . "\n" . '(ini adalah dokumen resmi dan sah)', 'QRCODE', 1, 1 ); ?>

                                </div>
                            </div>
                            <br>
                            <u><strong><?php echo e($trainer->user->name ?? '-'); ?></strong></u>
                            <br>
                            <span>STAFF <?php echo e($trainer->user->divisi ?? '-'); ?></span>
                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php $__currentLoopData = $event->trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="no-border text-center" style="width: 33.33%;">
                            <?php if($loop->iteration === 1): ?>
                                Semarang, <?php echo e($event->created_date ? \Carbon\Carbon::parse($event->created_date)->translatedFormat('d F Y') : now()->translatedFormat('d F Y')); ?>

                            <?php endif; ?>
                            <br>
                            Pembicara <?php echo e($loop->iteration); ?>

                            <br><br>
                            <div style="display: flex; justify-content: center;">
                                <div style="display: inline-block;">
                                    <?php echo DNS2D::getBarcodeHTML( $trainer->user->name . "\n" . 'STAFF ' . $trainer->user->divisi . "\n" . '(ini adalah dokumen resmi dan sah)', 'QRCODE', 1, 1 ); ?>

                                </div>
                            </div>
                            <br>
                            <u><strong><?php echo e($trainer->user->name ?? '-'); ?></strong></u>
                            <br>
                            <span>STAFF <?php echo e($trainer->user->divisi ?? '-'); ?></span>
                        </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php else: ?>
                <?php $__currentLoopData = $event->trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td class="no-border text-left" style="width:25%;">
                        <br>
                        Pembicara
                        <br>
                        <br>
                        <br>
                        <br>
                        <u><strong><?php echo e($trainer->external ?? '-'); ?></strong></u>
                    </td>
                    <td class="no-border" style="width:75%;"></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tr>
    </table>
    <p style="text-align: right">F.DUP.06.R.00.T.090217</p>
</body>
</html><?php /**PATH C:\laragon\www\learning-management-system\resources\views/pdf/training_attendance.blade.php ENDPATH**/ ?>