<?php 
$prefix_repeatable = (isset($repeatable))? true : false;
$preffix_method = (isset($method))? $method."_": "";
?>
<div class="<?php echo e((isset($field['class']))?$field['class']:'form-group'); ?>">
    <label><?php echo e((isset($field['label']))?$field['label']:'Label '.$key); ?> 
        <?php if(isset($field['required']) && $field['required']): ?>
        <small class="text-danger">*</small>
        <?php endif; ?>
    </label> <input type="checkbox" id="cb-all-<?php echo e($preffix_method); ?><?php echo e((isset($field['name']))?$field['name']:'id_'.$key); ?>">
    <div id="group-checklist-<?php echo e($preffix_method); ?><?php echo e((isset($field['name']))?$field['name']:'id_'.$key); ?>">
    </div>
</div>


<?php if(request('from_ajax') && request('from_ajax') == true): ?>
<div class="push-script">
<?php else: ?>
<?php $__env->startPush('scripts'); ?>
<?php endif; ?>
<script>
    $( document ).ready(function() {
        var countCb = 0
        var mId = "<?php echo e($preffix_method); ?><?php echo e((isset($field['name']))?$field['name']:'id_'.$key); ?>"
        $( "#cb-all-"+mId).on( "change", function() {
            $(".cb-"+mId).prop("checked", $(this).prop('checked'))
            countCb = 0
            if ($(this).prop('checked')) {
                countCb = $(".cb-"+mId).length
            }
        })

        $( document ).on( "ajaxComplete", function() {
            $("#cb-all-"+mId).prop("checked", $(".cb-"+mId+":checked").length == $(".cb-"+mId).length)
            $( ".cb-"+mId).on( "change", function() {
                if ($(this).prop('checked')) {
                    countCb ++
                }else{
                    countCb --
                }
                $("#cb-all-"+mId).prop("checked", countCb == $(".cb-"+mId).length)
            })
        } );
        
    });
</script>
<?php if(request('from_ajax') && request('from_ajax') == true): ?>
</div>
<?php else: ?>
<?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\learning-management-system\vendor\idevsmg\easyadmin\src/resources/views/backend/idev/fields/group_checklist.blade.php ENDPATH**/ ?>