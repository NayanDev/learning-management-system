<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Participant;
use App\Models\ResultQuestion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AssesmentController extends Controller
{
    public function assesment()
    {
        $token = request('token');
        if (!$token) {
            abort(404);
        }
        $data = Event::where('token', $token)
            ->first();
        $participantId = Participant::where('nik', Auth::user()->nik)->first();
        $resultQuestion = ResultQuestion::where('participant_id', $participantId->id)->first();

        // Get authenticated user
        $user = Auth::user();
        if (!$user) {
            abort(403, 'Unauthorized. Please login first.');
        }

        return view('backend.idev.assesment', compact('data', 'user', 'resultQuestion'));
    }
}
