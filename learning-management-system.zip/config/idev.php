<?php

return [
    'theme' => 'bluesy', // available : default, greeny, monochrome, bluesy, red
    'app_name' => 'LMS Sampharindo',
    // 'app_logo' => asset('easyadmin/idev/img/logo-idev.png'),
    // 'app_favicon' => asset('easyadmin/idev/img/favicon.png'),
    'enable_role' => true,
    'copyright' => 'Copyright &copy; Sampharindo Perdana',
];
